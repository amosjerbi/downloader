#!/bin/bash
# Multi-Platform ROM Launcher UI
# This script provides a user-friendly interface for searching and downloading ROMs for multiple platforms

# Debug mode
DEBUG=1
[ "$DEBUG" -eq 1 ] && echo "Starting Multi-Platform ROM Launcher UI..."

# Set target directory
ROMS_BASE_DIR="/Volumes/games-roms"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROM_LAUNCHER="$SCRIPT_DIR/rom_launcher.sh"

# Platform directories
NES_DIR="$ROMS_BASE_DIR/nes"
SNES_DIR="$ROMS_BASE_DIR/snes"
GENESIS_DIR="$ROMS_BASE_DIR/genesis"
GB_DIR="$ROMS_BASE_DIR/gb"
GBA_DIR="$ROMS_BASE_DIR/gba"

# Check if rom_launcher.sh exists and is executable
if [ ! -f "$ROM_LAUNCHER" ]; then
    echo "Error: rom_launcher.sh not found in $SCRIPT_DIR"
    exit 1
fi

if [ ! -x "$ROM_LAUNCHER" ]; then
    echo "Warning: rom_launcher.sh is not executable. Attempting to fix..."
    chmod +x "$ROM_LAUNCHER"
    if [ ! -x "$ROM_LAUNCHER" ]; then
        echo "Error: Could not make rom_launcher.sh executable"
        exit 1
    fi
    echo "Fixed permissions for rom_launcher.sh"
fi

# Create platform directories if they don't exist
for dir in "$NES_DIR" "$SNES_DIR" "$GENESIS_DIR" "$GB_DIR" "$GBA_DIR"; do
    if [ ! -d "$dir" ]; then
        echo "Creating directory: $dir"
        mkdir -p "$dir"
    fi
done

# Function to display header
display_header() {
    clear
    echo "========================================================"
    echo "             MULTI-PLATFORM ROM LAUNCHER                "
    echo "========================================================"
    echo "  Search and download ROMs for multiple platforms       "
    echo "========================================================"
    echo ""
}

# Function to display main menu
display_menu() {
    display_header
    echo "1. Search for ROMs"
    echo "2. View downloaded ROMs"
    echo "3. Exit"
    echo ""
    echo -n "Enter your choice (1-3): "
}

# Function to search for ROMs
search_rom() {
    local platform="$1"
    local platform_name="$2"
    local platform_dir="$3"
    
    display_header
    echo "Search for $platform_name ROMs"
    echo "========================================================"
    echo ""
    echo -n "Enter search term: "
    read -r search_term
    
    if [ -z "$search_term" ]; then
        echo "Search term cannot be empty. Press Enter to continue..."
        read -r
        return
    fi
    
    # Call the search_roms function from the main script
    "$ROM_LAUNCHER" "$platform" "$search_term"
    
    echo "Press Enter to continue..."
    read -r
}

# Function to view downloaded ROMs
view_downloaded_roms() {
    local platform="$1"
    local platform_name="$2"
    local platform_dir="$3"
    
    display_header
    echo "Downloaded $platform_name ROMs"
    echo "========================================================"
    echo ""
    
    if [ ! -d "$platform_dir" ]; then
        echo "Platform directory does not exist. Press Enter to continue..."
        read -r
        return
    fi
    
    # Count ROMs
    local rom_count=$(find "$platform_dir" -type f | wc -l)
    
    if [ "$rom_count" -eq 0 ]; then
        echo "No ROMs found in $platform_dir. Press Enter to continue..."
        read -r
        return
    fi
    
    echo "Found $rom_count ROMs in $platform_dir:"
    echo ""
    
    # List ROMs (sorted by name)
    find "$platform_dir" -type f -name "*.*" | sort | while read -r rom; do
        echo "- $(basename "$rom")"
    done
    
    echo ""
    echo "Press Enter to continue..."
    read -r
}

# Function to view all downloaded ROMs
view_all_roms() {
    display_header
    echo "All Downloaded ROMs"
    echo "========================================================"
    echo ""
    
    # Check each platform directory
    local total_count=0
    
    # NES ROMs
    if [ -d "$NES_DIR" ]; then
        local nes_count=$(find "$NES_DIR" -type f -name "*.nes" | wc -l)
        total_count=$((total_count + nes_count))
        echo "NES ROMs: $nes_count"
    else
        echo "NES ROMs: 0 (directory does not exist)"
    fi
    
    # SNES ROMs
    if [ -d "$SNES_DIR" ]; then
        local snes_count=$(find "$SNES_DIR" -type f -name "*.sfc" -o -name "*.smc" | wc -l)
        total_count=$((total_count + snes_count))
        echo "SNES ROMs: $snes_count"
    else
        echo "SNES ROMs: 0 (directory does not exist)"
    fi
    
    # Genesis ROMs
    if [ -d "$GENESIS_DIR" ]; then
        local genesis_count=$(find "$GENESIS_DIR" -type f -name "*.md" -o -name "*.bin" -o -name "*.gen" | wc -l)
        total_count=$((total_count + genesis_count))
        echo "Genesis ROMs: $genesis_count"
    else
        echo "Genesis ROMs: 0 (directory does not exist)"
    fi
    
    # Game Boy ROMs
    if [ -d "$GB_DIR" ]; then
        local gb_count=$(find "$GB_DIR" -type f -name "*.gb" | wc -l)
        total_count=$((total_count + gb_count))
        echo "Game Boy ROMs: $gb_count"
    else
        echo "Game Boy ROMs: 0 (directory does not exist)"
    fi
    
    # Game Boy Advance ROMs
    if [ -d "$GBA_DIR" ]; then
        local gba_count=$(find "$GBA_DIR" -type f -name "*.gba" | wc -l)
        total_count=$((total_count + gba_count))
        echo "Game Boy Advance ROMs: $gba_count"
    else
        echo "Game Boy Advance ROMs: 0 (directory does not exist)"
    fi
    
    echo ""
    echo "Total ROMs: $total_count"
    echo ""
    
    echo "Select a platform to view ROMs:"
    echo "1) NES"
    echo "2) SNES"
    echo "3) Genesis/Mega Drive"
    echo "4) Game Boy"
    echo "5) Game Boy Advance"
    echo "6) Return to main menu"
    echo ""
    echo -n "Enter your choice [1-6]: "
    read -r choice
    
    case $choice in
        1) view_downloaded_roms "nes" "NES" "$NES_DIR" ;;
        2) view_downloaded_roms "snes" "SNES" "$SNES_DIR" ;;
        3) view_downloaded_roms "genesis" "Genesis/Mega Drive" "$GENESIS_DIR" ;;
        4) view_downloaded_roms "gb" "Game Boy" "$GB_DIR" ;;
        5) view_downloaded_roms "gba" "Game Boy Advance" "$GBA_DIR" ;;
        *) return ;;
    esac
}

# Function to handle the search menu
search_for_roms() {
    display_header
    echo "Search for ROMs"
    echo "========================================================"
    echo ""
    echo "1. Nintendo Entertainment System (NES)"
    echo "2. Super Nintendo Entertainment System (SNES)"
    echo "3. Sega Genesis/Mega Drive"
    echo "4. Game Boy"
    echo "5. Game Boy Advance"
    echo "6. Back to main menu"
    echo ""
    echo -n "Select platform (1-6): "
    read -r platform_choice
    
    case "$platform_choice" in
        1)
            search_rom "nes" "NES" "$NES_DIR"
            ;;
        2)
            search_rom "snes" "SNES" "$SNES_DIR"
            ;;
        3)
            search_rom "genesis" "Genesis/Mega Drive" "$GENESIS_DIR"
            ;;
        4)
            search_rom "gb" "Game Boy" "$GB_DIR"
            ;;
        5)
            search_rom "gba" "Game Boy Advance" "$GBA_DIR"
            ;;
        6)
            return
            ;;
        *)
            echo "Invalid choice. Press Enter to continue..."
            read -r
            ;;
    esac
}

# Main function
main() {
    while true; do
        display_menu
        read -r choice
        
        case "$choice" in
            1)
                search_for_roms
                ;;
            2)
                view_all_roms
                ;;
            3)
                echo "Exiting ROM Launcher. Goodbye!"
                exit 0
                ;;
            *)
                echo "Invalid choice. Press Enter to continue..."
                read -r
                ;;
        esac
    done
}

# Start the main function
main
