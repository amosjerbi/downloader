#!/bin/bash
# Multi-Platform ROM Downloader
# This script downloads ROMs from Internet Archive for multiple platforms

# Debug mode
DEBUG=1
[ "$DEBUG" -eq 1 ] && echo "Starting Multi-Platform ROM Launcher..."

# Check for required commands
check_command() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Error: Required command '$1' not found. Please install it first."
    exit 1
  fi
}

# Check for required tools
check_command unzip
check_command grep
# We'll check for either curl or wget
if ! command -v curl >/dev/null 2>&1 && ! command -v wget >/dev/null 2>&1; then
  echo "Error: Neither curl nor wget is available. Please install one of them."
  exit 1
fi

# Set base directory for ROMs
ROMS_BASE_DIR="$HOME/Desktop/$(whoami)/games-roms"

# Set platform-specific directories
NES_DIR="$ROMS_BASE_DIR/nes"
SNES_DIR="$ROMS_BASE_DIR/snes"
GENESIS_DIR="$ROMS_BASE_DIR/genesis"
GB_DIR="$ROMS_BASE_DIR/gb"
GBA_DIR="$ROMS_BASE_DIR/gba"

# Create log directory and file
if [ -w "/tmp" ]; then
    LOG_DIR="/tmp"
else
    LOG_DIR="$ROMS_BASE_DIR"
fi
LOG_FILE="$LOG_DIR/rom_downloader_log.txt"
echo "ROM Downloader started at $(date)" > "$LOG_FILE"

# Function to log messages
log_message() {
  echo "$(date): $1" >> "$LOG_FILE"
  echo "$1"
}

# Function to display messages
display_message() {
  local message="$1"
  local type="$2"  # info, success, error, warning
  
  case "$type" in
    error)
      echo "ERROR: $message"
      ;;
    warning)
      echo "WARNING: $message"
      ;;
    success)
      echo "SUCCESS: $message"
      ;;
    *)
      echo "INFO: $message"
      ;;
  esac
}

# Function to display progress
display_progress() {
  local current="$1"
  local total="$2"
  local message="$3"
  echo "$message: $current/$total"
}

# Create ROM directory if it doesn't exist
if [ ! -d "$ROMS_BASE_DIR" ]; then
    if ! mkdir -p "$ROMS_BASE_DIR"; then
        display_message "Cannot create directory $ROMS_BASE_DIR. Please check permissions." "error"
        exit 1
    fi
fi

# Create NES directory if it doesn't exist
if [ ! -d "$NES_DIR" ]; then
    if ! mkdir -p "$NES_DIR"; then
        display_message "Cannot create NES directory $NES_DIR. Please check permissions." "error"
        exit 1
    fi
fi

# Create SNES directory if it doesn't exist
if [ ! -d "$SNES_DIR" ]; then
    if ! mkdir -p "$SNES_DIR"; then
        display_message "Cannot create SNES directory $SNES_DIR. Please check permissions." "error"
        exit 1
    fi
fi

# Create Genesis directory if it doesn't exist
if [ ! -d "$GENESIS_DIR" ]; then
    if ! mkdir -p "$GENESIS_DIR"; then
        display_message "Cannot create Genesis directory $GENESIS_DIR. Please check permissions." "error"
        exit 1
    fi
fi

# Create GB directory if it doesn't exist
if [ ! -d "$GB_DIR" ]; then
    if ! mkdir -p "$GB_DIR"; then
        display_message "Cannot create GB directory $GB_DIR. Please check permissions." "error"
        exit 1
    fi
fi

# Create GBA directory if it doesn't exist
if [ ! -d "$GBA_DIR" ]; then
    if ! mkdir -p "$GBA_DIR"; then
        display_message "Cannot create GBA directory $GBA_DIR. Please check permissions." "error"
        exit 1
    fi
fi

# Check if directories are writable
if [ ! -w "$ROMS_BASE_DIR" ]; then
    display_message "$ROMS_BASE_DIR is not writable" "error"
    exit 1
fi

if [ ! -w "$NES_DIR" ]; then
    display_message "$NES_DIR is not writable" "error"
    exit 1
fi

if [ ! -w "$SNES_DIR" ]; then
    display_message "$SNES_DIR is not writable" "error"
    exit 1
fi

if [ ! -w "$GENESIS_DIR" ]; then
    display_message "$GENESIS_DIR is not writable" "error"
    exit 1
fi

if [ ! -w "$GB_DIR" ]; then
    display_message "$GB_DIR is not writable" "error"
    exit 1
fi

if [ ! -w "$GBA_DIR" ]; then
    display_message "$GBA_DIR is not writable" "error"
    exit 1
fi

# Function to download a file with wget
download_with_wget() {
  local url="$1"
  local output_file="$2"
  if command -v wget >/dev/null 2>&1; then
    log_message "Attempting download with wget: $url"
    display_message "Attempting download with wget..." "info"
    wget -q --timeout=30 --tries=3 -O "$output_file" "$url"
    return $?
  fi
  return 1
}

# Function to download a file with curl
download_with_curl() {
  local url="$1"
  local output_file="$2"
  if command -v curl >/dev/null 2>&1; then
    log_message "Attempting download with curl: $url"
    display_message "Attempting download with curl..." "info"
    curl -s -L --connect-timeout 30 -o "$output_file" "$url"
    return $?
  fi
  return 1
}

# Function to check available space
check_space() {
    local required_space=$1  # in bytes
    local available_space
    
    if command -v df >/dev/null 2>&1; then
        # Get available space in blocks (512 bytes each on macOS)
        available_space=$(df "$ROMS_BASE_DIR" | awk 'NR==2 {print $4}')
        # Convert blocks to bytes (multiply by 512)
        available_space=$((available_space * 512))
        if [ "$available_space" -lt "$required_space" ]; then
            log_message "Error: Not enough space. Required: $(($required_space/1024/1024))MB, Available: $(($available_space/1024/1024))MB"
            display_message "Not enough space. Required: $(($required_space/1024/1024))MB, Available: $(($available_space/1024/1024))MB" "error"
            return 1
        fi
    fi
    return 0
}

# Function to download and extract ROM
download_rom() {
  local platform="$1"
  local rom_name="$2"
  local temp_dir
  local download_url=""
  local rom_file=""
  local is_nes_collection=0
  local is_snes_collection=0
  local is_genesis_collection=0
  local is_gb_collection=0
  local is_gba_collection=0
  
  # Create a temporary directory
  temp_dir=$(mktemp -d)
  if [ ! -d "$temp_dir" ]; then
    display_message "Failed to create temporary directory" "error"
    return 1
  fi
  
  # Set platform-specific variables
  case "$platform" in
    nes)
      download_url="https://archive.org/download/No-Intro-Collection_2016-01-03_Fixed/Nintendo%20-%20Nintendo%20Entertainment%20System.zip"
      platform_dir="$NES_DIR"
      is_nes_collection=1
      ;;
    snes)
      download_url="https://archive.org/download/snes-usa-romset-complete-collection.-7z"
      platform_dir="$SNES_DIR"
      is_snes_collection=1
      ;;
    genesis|md|megadrive)
      download_url="https://archive.org/download/sega-genesis-romset-ultra-usa"
      platform_dir="$GENESIS_DIR"
      is_genesis_collection=1
      ;;
    gb|gameboy)
      download_url="https://archive.org/download/Cyles_Gameboy_roms"
      platform_dir="$GB_DIR"
      is_gb_collection=1
      ;;
    gba|gameboy-advance)
      download_url="https://archive.org/download/GameboyAdvanceRomCollectionByGhostware"
      platform_dir="$GBA_DIR"
      is_gba_collection=1
      ;;
    *)
      display_message "Unknown platform: $platform" "error"
      rm -rf "$temp_dir"
      return 1
      ;;
  esac
  
  # Create platform directory if it doesn't exist
  if [ ! -d "$platform_dir" ]; then
    mkdir -p "$platform_dir"
  fi
  
  # Download the ROM
  display_message "Searching for \"$rom_name\" in $platform ROMs..." "info"
  
  # For collections with individual ROMs, we need to find the specific ROM
  if [ $is_snes_collection -eq 1 ] || [ $is_genesis_collection -eq 1 ] || [ $is_gb_collection -eq 1 ] || [ $is_gba_collection -eq 1 ]; then
    # Create a temporary file to store the HTML content
    local html_file="$temp_dir/${platform}_list.html"
    local matches_file="$temp_dir/matches.txt"
    
    # Download the directory listing
    if ! curl -s "$download_url" > "$html_file"; then
      if ! wget -q -O "$html_file" "$download_url"; then
        display_message "Failed to download $platform directory listing" "error"
        rm -rf "$temp_dir"
        return 1
      fi
    fi
    
    # Find matches based on the ROM name
    if [ $is_snes_collection -eq 1 ]; then
      grep -i "$rom_name" "$html_file" | grep -o 'href="[^"]*\.zip"' | grep -v "parent" | sed 's/href="//g' | sed 's/"//g' > "$matches_file"
    elif [ $is_genesis_collection -eq 1 ]; then
      grep -i "$rom_name" "$html_file" | grep -o 'href="[^"]*\.zip"' | grep -v "parent" | sed 's/href="//g' | sed 's/"//g' > "$matches_file"
    elif [ $is_gb_collection -eq 1 ]; then
      grep -i "$rom_name" "$html_file" | grep -o 'href="[^"]*\.zip"' | grep -v "parent" | sed 's/href="//g' | sed 's/"//g' > "$matches_file"
    elif [ $is_gba_collection -eq 1 ]; then
      grep -i "$rom_name" "$html_file" | grep -o 'href="[^"]*\.zip"' | grep -v "parent" | sed 's/href="//g' | sed 's/"//g' > "$matches_file"
    fi
    
    # Check if we found any matches
    if [ ! -s "$matches_file" ]; then
      display_message "No ROMs found matching \"$rom_name\"" "error"
      rm -rf "$temp_dir"
      return 1
    fi
    
    # Get the first match
    local rom_path=$(head -n 1 "$matches_file")
    
    # Download the ROM
    display_message "Downloading \"$rom_path\"..." "info"
    
    # Construct the download URL
    if [ $is_snes_collection -eq 1 ]; then
      rom_file="$temp_dir/$(basename "$rom_path")"
      if ! curl -s -L "$download_url/$rom_path" -o "$rom_file"; then
        if ! wget -q -O "$rom_file" "$download_url/$rom_path"; then
          display_message "Failed to download ROM" "error"
          rm -rf "$temp_dir"
          return 1
        fi
      fi
    elif [ $is_genesis_collection -eq 1 ]; then
      rom_file="$temp_dir/$(basename "$rom_path")"
      if ! curl -s -L "$download_url/$rom_path" -o "$rom_file"; then
        if ! wget -q -O "$rom_file" "$download_url/$rom_path"; then
          display_message "Failed to download ROM" "error"
          rm -rf "$temp_dir"
          return 1
        fi
      fi
    elif [ $is_gb_collection -eq 1 ]; then
      rom_file="$temp_dir/$(basename "$rom_path")"
      if ! curl -s -L "$download_url/$rom_path" -o "$rom_file"; then
        if ! wget -q -O "$rom_file" "$download_url/$rom_path"; then
          display_message "Failed to download ROM" "error"
          rm -rf "$temp_dir"
          return 1
        fi
      fi
    elif [ $is_gba_collection -eq 1 ]; then
      rom_file="$temp_dir/$(basename "$rom_path")"
      if ! curl -s -L "$download_url/$rom_path" -o "$rom_file"; then
        if ! wget -q -O "$rom_file" "$download_url/$rom_path"; then
          display_message "Failed to download ROM" "error"
          rm -rf "$temp_dir"
          return 1
        fi
      fi
    fi
  else
    # For NES, we download the entire collection and extract the specific ROM
    rom_file="$temp_dir/$(basename "$download_url")"
    
    display_message "Downloading ROM collection..." "info"
    
    if ! curl -s -L "$download_url" -o "$rom_file"; then
      if ! wget -q -O "$rom_file" "$download_url"; then
        display_message "Failed to download ROM collection" "error"
        rm -rf "$temp_dir"
        return 1
      fi
    fi
  fi
  
  # Extract the ROM
  display_message "Extracting ROM..." "info"
  
  if [ $is_nes_collection -eq 1 ]; then
    # For NES, extract the specific ROM from the collection
    if ! unzip -q -j "$rom_file" "*$rom_name*.nes" -d "$platform_dir"; then
      display_message "Failed to extract ROM from collection" "error"
      rm -rf "$temp_dir"
      return 1
    fi
  else
    # For other platforms, extract the individual ROM
    if ! unzip -q -o "$rom_file" -d "$platform_dir"; then
      display_message "Failed to extract ROM" "error"
      rm -rf "$temp_dir"
      return 1
    fi
  fi
  
  # Clean up
  rm -rf "$temp_dir"
  
  display_message "ROM downloaded and extracted successfully to $platform_dir" "success"
  return 0
}

# Function to search for ROMs and display results
search_roms() {
  local platform="$1"
  local search_term="$2"
  local temp_dir
  local results=()
  
  # Create a temporary directory
  temp_dir=$(mktemp -d)
  if [ ! -d "$temp_dir" ]; then
    display_message "Failed to create temporary directory" "error"
    return 1
  fi
  
  # Set platform-specific variables
  local platform_dir=""
  
  case "$platform" in
    nes)
      platform_dir="$NES_DIR"
      ;;
    snes)
      platform_dir="$SNES_DIR"
      ;;
    genesis|md|megadrive)
      platform_dir="$GENESIS_DIR"
      ;;
    gb|gameboy)
      platform_dir="$GB_DIR"
      ;;
    gba|gameboy-advance)
      platform_dir="$GBA_DIR"
      ;;
    *)
      display_message "Unknown platform: $platform" "error"
      rm -rf "$temp_dir"
      return 1
      ;;
  esac
  
  display_message "Searching for \"$search_term\" in $platform ROMs..." "info"
  
  # Create a file for search results
  local search_results="$temp_dir/search_results.txt"
  
  # Check if the platform directory exists and has ROMs
  if [ -d "$platform_dir" ] && [ "$(ls -A "$platform_dir" 2>/dev/null)" ]; then
    # Search for ROMs in the local directory
    case "$platform" in
      nes)
        find "$platform_dir" -type f -name "*.nes" | grep -i "$search_term" | sed 's/.*\///' | sed 's/\.nes$//' > "$search_results"
        ;;
      snes)
        find "$platform_dir" -type f -name "*.sfc" -o -name "*.smc" | grep -i "$search_term" | sed 's/.*\///' | sed 's/\.[^.]*$//' > "$search_results"
        ;;
      genesis|md|megadrive)
        find "$platform_dir" -type f -name "*.bin" -o -name "*.gen" -o -name "*.md" -o -name "*.smd" | grep -i "$search_term" | sed 's/.*\///' | sed 's/\.[^.]*$//' > "$search_results"
        ;;
      gb|gameboy)
        find "$platform_dir" -type f -name "*.gb" | grep -i "$search_term" | sed 's/.*\///' | sed 's/\.gb$//' > "$search_results"
        ;;
      gba|gameboy-advance)
        find "$platform_dir" -type f -name "*.gba" | grep -i "$search_term" | sed 's/.*\///' | sed 's/\.gba$//' > "$search_results"
        ;;
    esac
  else
    # If no local ROMs, create a mock list for testing
    display_message "No local ROMs found. Using mock data for testing." "info"
    
    case "$platform" in
      nes)
        echo "Super Mario Bros" > "$search_results"
        echo "Super Mario Bros 2" >> "$search_results"
        echo "Super Mario Bros 3" >> "$search_results"
        echo "Mario Bros" >> "$search_results"
        ;;
      snes)
        echo "Super Mario World" > "$search_results"
        echo "Super Mario All-Stars" >> "$search_results"
        echo "Super Mario RPG" >> "$search_results"
        echo "Mario Paint" >> "$search_results"
        echo "Mario's Time Machine" >> "$search_results"
        ;;
      genesis|md|megadrive)
        echo "Sonic the Hedgehog" > "$search_results"
        echo "Sonic the Hedgehog 2" >> "$search_results"
        echo "Sonic the Hedgehog 3" >> "$search_results"
        echo "Sonic & Knuckles" >> "$search_results"
        ;;
      gb|gameboy)
        echo "Pokemon Red" > "$search_results"
        echo "Pokemon Blue" >> "$search_results"
        echo "Pokemon Yellow" >> "$search_results"
        echo "Super Mario Land" >> "$search_results"
        echo "Super Mario Land 2" >> "$search_results"
        ;;
      gba|gameboy-advance)
        echo "Pokemon Ruby" > "$search_results"
        echo "Pokemon Sapphire" >> "$search_results"
        echo "Pokemon Emerald" >> "$search_results"
        echo "Super Mario Advance" >> "$search_results"
        echo "Mario & Luigi: Superstar Saga" >> "$search_results"
        ;;
    esac
    
    # Filter the mock list based on the search term
    grep -i "$search_term" "$search_results" > "$temp_dir/filtered.txt"
    mv "$temp_dir/filtered.txt" "$search_results"
  fi
  
  # Count search results
  local result_count=$(wc -l < "$search_results" | tr -d ' ')
  
  if [ "$result_count" -eq 0 ]; then
    display_message "No ROMs found matching \"$search_term\"" "warning"
    rm -rf "$temp_dir"
    return 1
  fi
  
  # Display search results
  display_message "Found $result_count ROMs matching \"$search_term\":" "info"
  echo "========================================================"
  
  # Read results into array
  local i=1
  while IFS= read -r line; do
    results+=("$line")
    echo "$i. $line"
    i=$((i+1))
  done < "$search_results"
  
  echo "========================================================"
  echo -n "Enter number to download (or 0 to cancel): "
  read -r choice
  
  # Check if choice is valid
  if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "$result_count" ]; then
    local selected_rom="${results[$((choice-1))]}"
    display_message "Downloading \"$selected_rom\"..." "info"
    download_rom "$platform" "$selected_rom"
    rm -rf "$temp_dir"
    return 0
  elif [ "$choice" -eq 0 ]; then
    display_message "Download canceled" "warning"
    rm -rf "$temp_dir"
    return 1
  else
    display_message "Invalid choice" "error"
    rm -rf "$temp_dir"
    return 1
  fi
}

# Display usage information
show_usage() {
  display_message "Usage: $0 <platform> <rom_name>" "warning"
  display_message "Supported platforms: nes, snes, genesis, gb, gba" "warning"
  display_message "Example: $0 nes \"Super Mario Bros\"" "warning"
  display_message "Example: $0 snes \"Donkey Kong Country\"" "warning"
  exit 1
}

# Check if platform and ROM name were provided
if [ $# -lt 2 ]; then
  show_usage
fi

# Get platform and ROM name
platform=$(echo "$1" | tr '[:upper:]' '[:lower:]')
shift
rom_name="$*"

# Search for ROMs
if ! search_roms "$platform" "$rom_name"; then
  display_message "Failed to download ROM. Check the log at $LOG_FILE for details." "error"
  exit 1
fi

exit 0